package com.aura.music

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

/** Queries MediaStore.Audio. Stable id = "ms:<MediaStore _ID>". Throws on failure. */
object MediaScanner {
    fun scan(ctx: Context): List<Track> {
        val base = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DISPLAY_NAME
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0"
        val seen = HashSet<Long>()
        val out = ArrayList<Track>()
        val cur = ctx.contentResolver.query(base, proj, sel, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
            ?: throw IllegalStateException("MediaStore returned no cursor")
        cur.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (!seen.add(id)) continue // duplicate guard
                val title = c.getString(1)?.takeIf { it.isNotBlank() }
                    ?: c.getString(5)?.substringBeforeLast('.') ?: "Unknown"
                out.add(Track(
                    "ms:$id", ContentUris.withAppendedId(base, id).toString(), title,
                    c.getString(2)?.takeIf { it != "<unknown>" } ?: "",
                    c.getString(3)?.takeIf { it != "<unknown>" } ?: "", c.getLong(4)
                ))
            }
        }
        return out
    }
}
