package com.aura.music

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class LibState { INIT, NEED_PERMISSION, DENIED, SCANNING, EMPTY, ERROR, READY }

data class UiState(
    val lib: LibState = LibState.INIT, val error: String? = null,
    val tracks: List<Track> = emptyList(), val query: String = "",
    val nowId: String? = null, val playing: Boolean = false,
    val pos: Long = 0L, val dur: Long = 0L, val toast: Int? = null
)

/** UI state mirrors the native MediaController; the service/ExoPlayer is the source of truth. */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState()); private set
    private var ctl: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync() }
        override fun onPlayerError(error: PlaybackException) {
            ui = ui.copy(toast = R.string.play_error)
            ctl?.let { if (it.hasNextMediaItem()) { it.seekToNextMediaItem(); it.prepare() } }
        }
    }

    init {
        val ctx = getApplication<Application>()
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({
            try { ctl = f.get().also { it.addListener(listener) }; sync() }
            catch (e: Exception) { ui = ui.copy(toast = R.string.service_error) }
        }, ContextCompat.getMainExecutor(ctx))
        viewModelScope.launch { while (true) { delay(500); if (ctl?.isPlaying == true) sync() } }
    }

    private fun sync() {
        val c = ctl ?: return
        ui = ui.copy(nowId = c.currentMediaItem?.mediaId, playing = c.isPlaying,
            pos = c.currentPosition.coerceAtLeast(0L), dur = if (c.duration == C.TIME_UNSET) 0L else c.duration)
    }

    fun onResume(granted: Boolean) {
        val l = ui.lib
        if (granted && (l == LibState.INIT || l == LibState.NEED_PERMISSION || l == LibState.DENIED)) scan()
        else if (!granted && l == LibState.INIT) ui = ui.copy(lib = LibState.NEED_PERMISSION)
        else if (!granted && l != LibState.NEED_PERMISSION && l != LibState.DENIED) ui = ui.copy(lib = LibState.DENIED)
    }
    fun onPermissionResult(ok: Boolean) { if (ok) scan() else ui = ui.copy(lib = LibState.DENIED) }

    fun scan() {
        ui = ui.copy(lib = LibState.SCANNING)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(getApplication<Application>()) } }
            ui = r.fold(
                { t -> ui.copy(lib = if (t.isEmpty()) LibState.EMPTY else LibState.READY, tracks = t, error = null) },
                { e -> ui.copy(lib = if (e is SecurityException) LibState.DENIED else LibState.ERROR, error = e.message) })
        }
    }

    fun setQuery(q: String) { ui = ui.copy(query = q) }
    fun clearToast() { ui = ui.copy(toast = null) }

    fun play(list: List<Track>, index: Int) {
        val items = list.map {
            MediaItem.Builder().setMediaId(it.id).setUri(it.uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).setAlbumTitle(it.album).build()).build()
        }
        val c = ctl ?: run { ui = ui.copy(toast = R.string.service_error); return }
        c.setMediaItems(items, index, 0L); c.prepare(); c.play()
    }
    fun toggle() { ctl?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { ctl?.let { it.seekToNextMediaItem(); it.prepare() } }
    fun seek(p: Long) { ctl?.seekTo(p) }

    override fun onCleared() { ctl?.release(); ctl = null }
}
