package com.aura.music

data class Track(
    val id: String, val uri: String, val title: String,
    val artist: String, val album: String, val duration: Long
)
