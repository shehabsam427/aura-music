package com.aura.music

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0E0F13)
private val Tx = Color(0xFFECEEF5)
private val Mut = Color(0xFF9AA0B4)
private val Accent = Color(0xFF8B7CF6)
private val Panel = Color(0x12FFFFFF)

private fun fmt(ms: Long): String { val s = ms / 1000; return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

@Composable
fun AuraApp(vm: PlayerViewModel, askAudio: () -> Unit, openSettings: () -> Unit, askNotif: () -> Unit) {
    val s = vm.ui
    val ctx = LocalContext.current
    LaunchedEffect(s.toast) { s.toast?.let { Toast.makeText(ctx, ctx.getString(it), Toast.LENGTH_SHORT).show(); vm.clearToast() } }
    LaunchedEffect(s.lib == LibState.READY) { if (s.lib == LibState.READY) askNotif() }
    val shown = remember(s.tracks, s.query) {
        val q = s.query.trim().lowercase()
        if (q.isEmpty()) s.tracks else s.tracks.filter { "${it.title} ${it.artist} ${it.album}".lowercase().contains(q) }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg, onSurface = Tx)) {
        Scaffold(containerColor = Bg,
            topBar = {
                Column(Modifier.statusBarsPadding().padding(16.dp, 12.dp, 16.dp, 4.dp)) {
                    Text(stringResource(R.string.app_name), color = Tx, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    if (s.tracks.isNotEmpty() && (s.lib == LibState.READY))
                        OutlinedTextField(s.query, vm::setQuery, singleLine = true,
                            placeholder = { Text(stringResource(R.string.search_hint)) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            },
            bottomBar = { MiniPlayer(vm) }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (s.lib) {
                    LibState.INIT, LibState.SCANNING -> Message(R.string.scanning, stringResource(R.string.scanning_body), null, null)
                    LibState.NEED_PERMISSION -> Message(R.string.allow_title, stringResource(R.string.allow_body), R.string.allow, askAudio)
                    LibState.DENIED -> Message(R.string.denied_title, stringResource(R.string.denied_body), R.string.open_settings, openSettings, R.string.try_again, askAudio)
                    LibState.EMPTY -> Message(R.string.empty_title, stringResource(R.string.empty_body), R.string.scan_again, vm::scan)
                    LibState.ERROR -> Message(R.string.error_title, s.error ?: "", R.string.try_again, vm::scan)
                    LibState.READY ->
                        if (shown.isEmpty()) Message(R.string.no_matches, stringResource(R.string.no_matches_body), null, null)
                        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp, 0.dp, 8.dp, 8.dp)) {
                            itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .background(if (t.id == s.nowId) Panel else Color.Transparent)
                                    .clickable { vm.play(shown, i) }.padding(12.dp, 10.dp)) {
                                    Text(t.title, color = Tx, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(listOf(t.artist, t.album, fmt(t.duration)).filter { it.isNotEmpty() }.joinToString(" · "),
                                        color = Mut, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                }
            }
        }
    }
}

@Composable
private fun Message(title: Int, body: String, a1: Int?, f1: (() -> Unit)?, a2: Int? = null, f2: (() -> Unit)? = null) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(stringResource(title), color = Tx, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(body, color = Mut, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 12.dp))
        if (a1 != null && f1 != null) Button(f1, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text(stringResource(a1)) }
        if (a2 != null && f2 != null) TextButton(f2) { Text(stringResource(a2)) }
    }
}

@Composable
private fun MiniPlayer(vm: PlayerViewModel) {
    val s = vm.ui
    val t = s.tracks.firstOrNull { it.id == s.nowId } ?: return
    var drag by remember { mutableStateOf<Float?>(null) }
    Column(Modifier.navigationBarsPadding().padding(8.dp).clip(RoundedCornerShape(18.dp))
        .background(Color(0xE61C1D24)).padding(12.dp, 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.title, color = Tx, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(t.artist, color = Mut, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(vm::toggle) { Text(if (s.playing) "⏸" else "▶", fontSize = 20.sp, color = Tx) }
            TextButton(vm::next) { Text("⏭", fontSize = 20.sp, color = Tx) }
        }
        val max = (if (s.dur > 0) s.dur else t.duration).coerceAtLeast(1L).toFloat()
        Slider(value = (drag ?: s.pos.toFloat()).coerceIn(0f, max), valueRange = 0f..max,
            onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
    }
}
